module.exports = {
  topic: "Neo4jPersonTopic",
  brokers:
    "b-1.neo4j-kafka.wqfvy4.c3.kafka.us-west-2.amazonaws.com:9094,b-2.neo4j-kafka.wqfvy4.c3.kafka.us-west-2.amazonaws.com:9094"
};
